import sys
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

ADDON = xbmcaddon.Addon()
ADDON_HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]


def build_url(query):
    return BASE_URL + "?" + urllib.parse.urlencode(query)


def root_menu():
    items = [
        ("Artists", {"action": "artists"}),
        ("Albums", {"action": "albums"}),
        ("Playlists", {"action": "playlists"}),
    ]

    for label, query in items:
        url = build_url(query)
        li = xbmcgui.ListItem(label=label)
        li.setInfo("music", {"title": label})
        xbmcplugin.addDirectoryItem(
            handle=ADDON_HANDLE,
            url=url,
            listitem=li,
            isFolder=True,
        )

    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def placeholder(label):
    li = xbmcgui.ListItem(label=f"{label} (coming soon)")
    xbmcplugin.addDirectoryItem(
        handle=ADDON_HANDLE,
        url="",
        listitem=li,
        isFolder=False,
    )
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    action = params.get("action")

    if action is None:
        root_menu()
    elif action == "artists":
        placeholder("Artists")
    elif action == "albums":
        placeholder("Albums")
    elif action == "playlists":
        placeholder("Playlists")
    else:
        xbmc.log(f"Unknown action: {action}", xbmc.LOGWARNING)
        root_menu()


if __name__ == "__main__":
    router(sys.argv[2][1:])