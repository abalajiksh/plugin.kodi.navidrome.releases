import sys
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

# Import our API wrapper
from lib.navidrome_api import NavidromeAPI

ADDON = xbmcaddon.Addon()
ADDON_HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]


def get_api():
    """Get configured API instance"""
    server_url = ADDON.getSetting('server_url')
    username = ADDON.getSetting('username')
    password = ADDON.getSetting('password')
    
    if not server_url or not username or not password:
        xbmcgui.Dialog().notification(
            'Navidrome',
            'Please configure server settings',
            xbmcgui.NOTIFICATION_WARNING
        )
        return None
    
    return NavidromeAPI(server_url, username, password)


def build_url(query):
    return BASE_URL + "?" + urllib.parse.urlencode(query)


def root_menu():
    """Main menu"""
    items = [
        ("Artists", {"action": "artists"}),
        ("Albums", {"action": "albums"}),
        ("Recently Added", {"action": "recent"}),
        ("Random Albums", {"action": "random"}),
        ("Playlists", {"action": "playlists"}),
        ("Search", {"action": "search"}),
    ]

    for label, query in items:
        url = build_url(query)
        li = xbmcgui.ListItem(label=label)
        li.setInfo("music", {"title": label})
        xbmcplugin.addDirectoryItem(
            handle=ADDON_HANDLE,
            url=url,
            listitem=li,
            isFolder=True,
        )

    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def list_artists():
    """List all artists"""
    api = get_api()
    if not api:
        return
    
    # Test connection first
    if not api.ping():
        xbmcgui.Dialog().notification(
            'Navidrome',
            'Failed to connect to server',
            xbmcgui.NOTIFICATION_ERROR
        )
        return
    
    artists = api.get_artists()
    
    if not artists:
        xbmcgui.Dialog().notification(
            'Navidrome',
            'No artists found',
            xbmcgui.NOTIFICATION_INFO
        )
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return
    
    for artist in artists:
        artist_id = artist.get('id')
        name = artist.get('name', 'Unknown Artist')
        
        url = build_url({"action": "artist", "id": artist_id})
        li = xbmcgui.ListItem(label=name)
        
        # Set artist info
        li.setInfo("music", {
            "title": name,
            "artist": name,
            "mediatype": "artist"
        })
        
        # Add cover art if available
        cover_art = artist.get('coverArt')
        if cover_art:
            art_url = api.get_cover_art_url(cover_art)
            li.setArt({"thumb": art_url, "fanart": art_url})
        
        xbmcplugin.addDirectoryItem(
            handle=ADDON_HANDLE,
            url=url,
            listitem=li,
            isFolder=True
        )
    
    xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_ARTIST)
    xbmcplugin.setContent(ADDON_HANDLE, 'artists')
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def list_artist_albums(artist_id):
    """List albums for a specific artist"""
    api = get_api()
    if not api:
        return
    
    artist = api.get_artist(artist_id)
    
    if not artist:
        xbmcgui.Dialog().notification(
            'Navidrome',
            'Failed to load artist',
            xbmcgui.NOTIFICATION_ERROR
        )
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return
    
    albums = artist.get('album', [])
    
    for album in albums:
        add_album_item(api, album)
    
    xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_ALBUM)
    xbmcplugin.setContent(ADDON_HANDLE, 'albums')
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def add_album_item(api, album):
    """Helper function to add an album list item"""
    album_id = album.get('id')
    title = album.get('name', 'Unknown Album')
    artist_name = album.get('artist', 'Unknown Artist')
    year = album.get('year', '')
    
    url = build_url({"action": "album", "id": album_id})
    li = xbmcgui.ListItem(label=title)
    
    # Set album info
    li.setInfo("music", {
        "title": title,
        "album": title,
        "artist": artist_name,
        "year": year,
        "mediatype": "album"
    })
    
    # Add cover art
    cover_art = album.get('coverArt')
    if cover_art:
        art_url = api.get_cover_art_url(cover_art)
        li.setArt({"thumb": art_url, "fanart": art_url})
    
    xbmcplugin.addDirectoryItem(
        handle=ADDON_HANDLE,
        url=url,
        listitem=li,
        isFolder=True
    )


def list_album_tracks(album_id):
    """List tracks for a specific album"""
    api = get_api()
    if not api:
        return
    
    album = api.get_album(album_id)
    
    if not album:
        xbmcgui.Dialog().notification(
            'Navidrome',
            'Failed to load album',
            xbmcgui.NOTIFICATION_ERROR
        )
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return
    
    tracks = album.get('song', [])
    
    for track in tracks:
        add_track_item(api, track)
    
    xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_TRACKNUM)
    xbmcplugin.setContent(ADDON_HANDLE, 'songs')
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def add_track_item(api, track):
    """Helper function to add a track list item"""
    track_id = track.get('id')
    title = track.get('title', 'Unknown Track')
    artist = track.get('artist', 'Unknown Artist')
    album_name = track.get('album', 'Unknown Album')
    duration = track.get('duration', 0)
    track_number = track.get('track', 0)
    year = track.get('year', '')
    
    # For now, use direct HTTP URL (we'll switch to VFS later)
    stream_url = api.get_stream_url(track_id)
    
    li = xbmcgui.ListItem(label=title)
    
    # Set track info
    li.setInfo("music", {
        "title": title,
        "artist": artist,
        "album": album_name,
        "duration": duration,
        "tracknumber": track_number,
        "year": year,
        "mediatype": "song"
    })
    
    # Add cover art
    cover_art = track.get('coverArt')
    if cover_art:
        art_url = api.get_cover_art_url(cover_art)
        li.setArt({"thumb": art_url})
    
    # Mark as playable
    li.setProperty('IsPlayable', 'true')
    
    xbmcplugin.addDirectoryItem(
        handle=ADDON_HANDLE,
        url=stream_url,
        listitem=li,
        isFolder=False
    )


def list_albums():
    """List all albums"""
    api = get_api()
    if not api:
        return
    
    # Get all albums via the album list endpoint
    albums = api.get_album_list('alphabeticalByName')
    
    if not albums:
        xbmcgui.Dialog().notification(
            'Navidrome',
            'No albums found',
            xbmcgui.NOTIFICATION_INFO
        )
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return
    
    for album in albums:
        add_album_item(api, album)
    
    xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_ALBUM)
    xbmcplugin.setContent(ADDON_HANDLE, 'albums')
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def list_recent_albums():
    """List recently added albums"""
    api = get_api()
    if not api:
        return
    
    albums = api.get_album_list('newest', size=50)
    
    if not albums:
        xbmcgui.Dialog().notification(
            'Navidrome',
            'No albums found',
            xbmcgui.NOTIFICATION_INFO
        )
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return
    
    for album in albums:
        add_album_item(api, album)
    
    xbmcplugin.setContent(ADDON_HANDLE, 'albums')
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def list_random_albums():
    """List random albums"""
    api = get_api()
    if not api:
        return
    
    albums = api.get_album_list('random', size=50)
    
    if not albums:
        xbmcgui.Dialog().notification(
            'Navidrome',
            'No albums found',
            xbmcgui.NOTIFICATION_INFO
        )
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return
    
    for album in albums:
        add_album_item(api, album)
    
    xbmcplugin.setContent(ADDON_HANDLE, 'albums')
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def list_playlists():
    """List all playlists"""
    api = get_api()
    if not api:
        return
    
    playlists = api.get_playlists()
    
    if not playlists:
        xbmcgui.Dialog().notification(
            'Navidrome',
            'No playlists found',
            xbmcgui.NOTIFICATION_INFO
        )
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return
    
    for playlist in playlists:
        playlist_id = playlist.get('id')
        name = playlist.get('name', 'Unknown Playlist')
        song_count = playlist.get('songCount', 0)
        
        url = build_url({"action": "playlist", "id": playlist_id})
        li = xbmcgui.ListItem(label=f"{name} ({song_count} tracks)")
        
        li.setInfo("music", {
            "title": name,
            "mediatype": "playlist"
        })
        
        # Add cover art if available
        cover_art = playlist.get('coverArt')
        if cover_art:
            art_url = api.get_cover_art_url(cover_art)
            li.setArt({"thumb": art_url})
        
        xbmcplugin.addDirectoryItem(
            handle=ADDON_HANDLE,
            url=url,
            listitem=li,
            isFolder=True
        )
    
    xbmcplugin.setContent(ADDON_HANDLE, 'playlists')
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def list_playlist_tracks(playlist_id):
    """List tracks in a playlist"""
    api = get_api()
    if not api:
        return
    
    playlist = api.get_playlist(playlist_id)
    
    if not playlist:
        xbmcgui.Dialog().notification(
            'Navidrome',
            'Failed to load playlist',
            xbmcgui.NOTIFICATION_ERROR
        )
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return
    
    tracks = playlist.get('entry', [])
    
    for track in tracks:
        add_track_item(api, track)
    
    xbmcplugin.setContent(ADDON_HANDLE, 'songs')
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def search():
    """Search for music"""
    dialog = xbmcgui.Dialog()
    query = dialog.input('Search')
    
    if not query:
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return
    
    api = get_api()
    if not api:
        return
    
    results = api.search(query)
    
    if not results:
        xbmcgui.Dialog().notification(
            'Navidrome',
            'No results found',
            xbmcgui.NOTIFICATION_INFO
        )
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return
    
    # Add artists
    for artist in results.get('artist', []):
        artist_id = artist.get('id')
        name = artist.get('name', 'Unknown Artist')
        
        url = build_url({"action": "artist", "id": artist_id})
        li = xbmcgui.ListItem(label=f"[Artist] {name}")
        
        li.setInfo("music", {
            "title": name,
            "artist": name,
            "mediatype": "artist"
        })
        
        cover_art = artist.get('coverArt')
        if cover_art:
            art_url = api.get_cover_art_url(cover_art)
            li.setArt({"thumb": art_url})
        
        xbmcplugin.addDirectoryItem(
            handle=ADDON_HANDLE,
            url=url,
            listitem=li,
            isFolder=True
        )
    
    # Add albums
    for album in results.get('album', []):
        add_album_item(api, album)
    
    # Add songs
    for track in results.get('song', []):
        add_track_item(api, track)
    
    xbmcplugin.setContent(ADDON_HANDLE, 'mixed')
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def router(paramstring):
    """Route to the appropriate function"""
    params = dict(urllib.parse.parse_qsl(paramstring))
    action = params.get("action")

    if action is None:
        root_menu()
    elif action == "artists":
        list_artists()
    elif action == "artist":
        list_artist_albums(params.get("id"))
    elif action == "albums":
        list_albums()
    elif action == "album":
        list_album_tracks(params.get("id"))
    elif action == "recent":
        list_recent_albums()
    elif action == "random":
        list_random_albums()
    elif action == "playlists":
        list_playlists()
    elif action == "playlist":
        list_playlist_tracks(params.get("id"))
    elif action == "search":
        search()
    else:
        xbmc.log(f"Unknown action: {action}", xbmc.LOGWARNING)
        root_menu()


if __name__ == "__main__":
    router(sys.argv[2][1:])