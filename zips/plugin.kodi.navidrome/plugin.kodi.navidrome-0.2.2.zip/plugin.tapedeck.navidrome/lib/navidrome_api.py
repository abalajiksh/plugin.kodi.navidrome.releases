import hashlib
import random
import string
import time
import urllib.parse
import urllib.request
import json
import xbmc


class NavidromeAPI:
    """Wrapper for Navidrome's Subsonic API"""
    
    def __init__(self, server_url, username, password):
        self.server_url = server_url.rstrip('/')
        self.username = username
        self.password = password
        self.client_name = "Kodi-Navidrome"
        self.api_version = "1.16.1"
    
    def _generate_token(self):
        """Generate salt and token for Subsonic authentication"""
        salt = ''.join(random.choices(string.ascii_letters + string.digits, k=8))
        token = hashlib.md5((self.password + salt).encode()).hexdigest()
        return salt, token
    
    def _build_url(self, endpoint, params=None):
        """Build a complete API URL with authentication"""
        if params is None:
            params = {}
        
        salt, token = self._generate_token()
        
        auth_params = {
            'u': self.username,
            't': token,
            's': salt,
            'v': self.api_version,
            'c': self.client_name,
            'f': 'json'
        }
        
        params.update(auth_params)
        url = f"{self.server_url}/rest/{endpoint}?{urllib.parse.urlencode(params)}"
        
        xbmc.log(f"NAVIDROME API: {endpoint} - {url}", xbmc.LOGDEBUG)
        return url
    
    def _make_request(self, endpoint, params=None):
        """Make an API request and return JSON response"""
        try:
            url = self._build_url(endpoint, params)
            
            with urllib.request.urlopen(url, timeout=10) as response:
                data = json.loads(response.read().decode('utf-8'))
                
                # Check for Subsonic API errors
                if 'subsonic-response' in data:
                    subsonic_response = data['subsonic-response']
                    if subsonic_response.get('status') == 'failed':
                        error = subsonic_response.get('error', {})
                        error_msg = error.get('message', 'Unknown error')
                        xbmc.log(f"NAVIDROME API ERROR: {error_msg}", xbmc.LOGERROR)
                        return None
                    return subsonic_response
                
                return data
                
        except urllib.error.HTTPError as e:
            xbmc.log(f"NAVIDROME HTTP ERROR: {e.code} - {e.reason}", xbmc.LOGERROR)
            return None
        except urllib.error.URLError as e:
            xbmc.log(f"NAVIDROME URL ERROR: {e.reason}", xbmc.LOGERROR)
            return None
        except Exception as e:
            xbmc.log(f"NAVIDROME ERROR: {str(e)}", xbmc.LOGERROR)
            return None
    
    def ping(self):
        """Test connection to server"""
        response = self._make_request('ping')
        return response is not None and response.get('status') == 'ok'
    
    def get_artists(self):
        """Get all artists"""
        response = self._make_request('getArtists')
        if response and 'artists' in response:
            # Subsonic returns artists grouped by index
            all_artists = []
            for index in response['artists'].get('index', []):
                all_artists.extend(index.get('artist', []))
            return all_artists
        return []
    
    def get_artist(self, artist_id):
        """Get artist details including albums"""
        response = self._make_request('getArtist', {'id': artist_id})
        if response and 'artist' in response:
            return response['artist']
        return None
    
    def get_album(self, album_id):
        """Get album details including tracks"""
        response = self._make_request('getAlbum', {'id': album_id})
        if response and 'album' in response:
            return response['album']
        return None
    
    def get_playlists(self):
        """Get all playlists"""
        response = self._make_request('getPlaylists')
        if response and 'playlists' in response:
            return response['playlists'].get('playlist', [])
        return []
    
    def get_playlist(self, playlist_id):
        """Get playlist details including tracks"""
        response = self._make_request('getPlaylist', {'id': playlist_id})
        if response and 'playlist' in response:
            return response['playlist']
        return None
    
    def search(self, query):
        """Search for artists, albums, and songs"""
        response = self._make_request('search3', {
            'query': query,
            'artistCount': 20,
            'albumCount': 20,
            'songCount': 50
        })
        if response and 'searchResult3' in response:
            return response['searchResult3']
        return None
    
    def get_cover_art_url(self, cover_id, size=300):
        """Get cover art URL"""
        if not cover_id:
            return None
        return self._build_url('getCoverArt', {'id': cover_id, 'size': size})
    
    def get_stream_url(self, track_id):
        """Get stream URL for a track"""
        return self._build_url('stream', {'id': track_id})
    
    def scrobble(self, track_id, submission=True):
        """Scrobble a track (update play count)"""
        params = {'id': track_id, 'submission': str(submission).lower()}
        response = self._make_request('scrobble', params)
        return response is not None
    
    def update_now_playing(self, track_id):
        """Update now playing status"""
        response = self._make_request('scrobble', {'id': track_id, 'submission': 'false', 'time': int(time.time() * 1000)})
        return response is not None
    
    def get_album_list(self, list_type='alphabeticalByName', size=500, offset=0):
        """
        Get album list
        Types: random, newest, highest, frequent, recent, alphabeticalByName, alphabeticalByArtist
        """
        response = self._make_request('getAlbumList2', {
            'type': list_type,
            'size': size,
            'offset': offset
        })
        if response and 'albumList2' in response:
            return response['albumList2'].get('album', [])
        return []